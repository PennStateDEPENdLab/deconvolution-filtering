function y = dsigmoid(x)
    y=(1-sigmoid(x)).*sigmoid(x);
end


    
